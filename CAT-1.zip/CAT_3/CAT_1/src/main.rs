use std::io;
  fn main() {
    let mut inputc=String::new();
    println!("input temperatur celsius");
    io::stdin().read_line(&mut inputc).expect("not a valid string");
    let c:f32 = inputc.trim().parse().expect("not a validnumber");

    let mut inputf=String::new();
    io::stdin().read_line(&mut inputf).expect("not a valid string");
    let f:f32 = inputf.trim().parse().expect("not a validnumber");
   
    
    
    //for fahrenheit
    let convert_fahrenheit = f = 9.0/5.0 * C + 32.0;
    println!("convert_fahrenheit");

    //for kelvin
    let convert_temperature  = c + 273.15;
    println!("convert_temperature");

    if let condition = 0 {
         println!("freezing point");}
    else if let condition=0 || 30{
        println!("normal range");
    }
    else{
        println!("hot temperature");
    }
   
    
     }