use std::io;

fn main () {
    let mut inputR= String::new();
    let mut inputA= String::new();
    let mut inputD= String::new();
    let mut inputN= String::new();

   let mut inputR=("rust for beginners");
   println!("{}"15000);
   let mut inputA=("AI basics");
   println!("{}"12500);
   let mut inputD=("Data structures in rust");
   println!("{}"20000);
   let mut inputN=("Networking Essentials")
   println!("{}"18000);


    println!("Enter code");
    io::stdin().read_line(&mut inputR).expect("not a valid string");
    let R:f32 = inputR.trim().parse().expect("not a validnumber");

     println!("Enter code");
    io::stdin().read_line(&mut inputA).expect("not a valid string");
    let A:f32 = inputA.trim().parse().expect("not a validnumber");
    

     println!("Enter code");
    io::stdin().read_line(&mut inputD).expect("not a valid string");
    let D:f32 = inputD.trim().parse().expect("not a validnumber");

     println!("Enter code");
    io::stdin().read_line(&mut inputF).expect("not a valid string");
    let F:f32 = inputN.trim().parse().expect("not a validnumber");


 let total_amount = (R + A + D + F);
       println!("total_amount");
  if customer_buys =("3 books");
    println!("discount of 10%");

println!("Display an amount payable");
 if customer loop {"allow multiple coustmers"}
 return;
}