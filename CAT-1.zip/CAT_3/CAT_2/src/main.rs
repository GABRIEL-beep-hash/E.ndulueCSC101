
        use std::io;

fn main() {
    let mut math = String::new();
    let mut physics = String::new();
    let mut computer = String::new();

    println!("Enter score for Math: ");
    io::stdin().read_line(&mut math).expect("Failed to read input");

    println!("Enter score for Physics: ");
    io::stdin().read_line(&mut physics).expect("Failed to read input");

    println!("Enter score for Computer Science: ");
    io::stdin().read_line(&mut computer).expect("Failed to read input");

    let math: f64 = math.trim().parse().expect("Please enter a number");
    let physics: f64 = physics.trim().parse().expect("Please enter a number");
    let computer: f64 = computer.trim().parse().expect("Please enter a number");

    let average = (math + physics + computer) / 3.0;

    println!("Average");

    if average >= 70.0 {
        println!("Result: Pass");
        println!("Grade: A");
    } else if average >= 60.0 {
        println!("Result: Pass");
        println!("Grade: B");
    } else if average >= 50.0 {
        println!("Result: Pass");
        println!("Grade: C");
    } else if average >= 45.0 {
        println!("Result: Pass");
        println!("Grade: D");
    } else {
        println!("Result: Fail");
        println!("Grade: F");
    }


}


